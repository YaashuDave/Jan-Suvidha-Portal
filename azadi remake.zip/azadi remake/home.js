function agriculture() {
    document.getElementById("container");
    window.location = "agricultural.html";
  }

  function home() {
    document.getElementById("container");
    window.location = "home.html";
    
  }

  // function aboutus() {
  //   document.getElementById("container");
  //   window.location = "C:\\Users\\vrajp\\Documents\\Azadi\\.vscode\\navebar\\aboutus.html";
  // }

  function health() {
    document.getElementById("container");
    window.location= "health.html";
  }

  function education() {
    document.getElementById("container");
    window.location= "education.html";
  }
  function achivements() {
    document.getElementById("container");
    window.location= "achivements.html";
  }
  function photo() {
    document.getElementById("container");
    window.location= "photo.html";
  }
  function aboutguj() {
    document.getElementById("container");
    window.location= "aboutguj.html";
  }


  function development() {
    document.getElementById("container");
    window.location= "development.html";
  }

  function general() {
    document.getElementById("container");
    window.location= "general.html";
  }

  function aplication() {
    document.getElementById("container");
    window.location= "aplication.html";
  }

  function map() {
    document.getElementById("container");
    window.location= "map.html";
  }

  function upload() {
    document.getElementById("container");
    window.location= "upload.html";
  }

  function faq() {
    document.getElementById("container");
    window.location= "faq.html";
  }
  function objective() {
    document.getElementById("container");
    window.location= "objective.html";
  }
